### MIDTERM ###
# complete the analysis below.
# most questions just require code -- no need to copy output or write comments/words.
# some questions are for you to answer with comments/words -- those are indicated.
# there are hints at the bottom if you get stuck, but try it without hints first.
# remember, your goal is to make sure you understand the material to solve this!


##### section 0: GET STARTED ##########

# 0.1 load the packages you need


# 0.2 load the nettle.csv data and assign it to a variable 


# 0.3 take a look at the data using a few functions of your choice


# 0.4 which variables are categorical and which are continuous?
# (answer in words/comments)


# This data comes from Nettle (1998).
#
# This paper discusses how there are 6500 languages but they are not evenly distributed geographically.
# They investigated the relationship between weather patterns and language diversity,
# specifically wondering whether places with longer growing seasons have more language diversity.
#
# Each row of the data represents one country.  Other variables are:
# continent -- which continent the country belongs to
# langs -- number of languages spoken there
# population -- number of millions of people living there
# area -- the area of the country in square kilometers
# growing.season -- the average number of months of the year that crops can grow

# 0.5 what are the outcome and predictor variables?
# (answer in words/comments)



##### section 1: CHECKING OUT THE DATA ##########

# 1.1 what is the total area, population, and number of languages in the data?


# 1.2 how many countries in each continent are in the data?


# 1.3 how many languages are in each continent?


# 1.4 what is the mean growing season of each continent?


# 1.5 which countries have the most languages?



##### section 2: VISUALISING THE DATA ##########

# 2.1 what would you expect the relationship to be between number of languages and population?
# (answer in words/comments)


# 2.2 create a graph to visualise the relationship between number of languages and population


# 2.3 create that same graph but broken down by continent


# 2.4 you can see a few countries have way more languages than most countries do.
# copy paste your 2.2 code here and add a filter to remove countries with more than 250 languages


# 2.5 what does it look like the relationship is between number of languages and population?
# (answer in words/comments)



##### section 3: LANGUAGE DENSITY ##########

# 3.1 given the relationship between number of languages and population,
# we're going to continue the analysis with a new outcome variable.
# create a variable called langs.per.pop with the number of languages spoken per million people


# 3.2 copy your code from 3.1 below. then:
# -add to your code above to create a scatterplot of your new variable and growing season
# -add to your code above to cut off outliers to make the relationship between the variables easier to see
# -add to your code above a meaningful title and x and y axis labels


# 3.3 write a description of the plot you just created
# (answer in words/comments)


# 3.4 what does it look like the relationship is between langs.per.pop and growing.season?
# (answer in words/comments)


# 3.5 how does this relate to the original research question?
# (answer in words/comments)



##### section 4: CONFIDENCE INTERVALS ##########

# 4.1 create a binned categorical variable from growing season called long.season
# that has TRUE and FALSE based on whether the growing season is longer than the median growing season


# 4.2 you just created long.season using a logical expression,
# which creates a variable where all of the values are TRUE or FALSE.
# if you want the values to be something more informative,
# you can use the function if_else(logical_expression, value_if_true, value_if_false).
# try creating a variable called season.length using if_else().
# use the same logical expression as you did in 4.1,
# and "long" and "short" for the other two arguments of if_else().


# 4.3 let's say your research hypothesis is that countries with long growing seasons
# have a higher language density (langs.per.pop) than countries with short growing seasons.
# write the null and alternative hypotheses corresponding to this research hypothesis.
# (answer in words/comments)


# 4.4 copy your code from 3.1 to create your langs.per.pop variable
# and add the relevant code from 4.2 to create your season.length variable.
# (check that runs before you add more!)
# calculate the mean langs.per.pop for long vs short growing seasons,
# as well as the 95% confidence intervals around those means.


# 4.5 what can or can't you conclude based on these confidence intervals? why?
# (answer in words/comments)





### HINTS ###
# 0.2 hint->####################################################################################################################### use the function read_csv()
# 1.1 hint->####################################################################################################################### this requires summarise()
# 1.5 hint->####################################################################################################################### you can pipe any dataframe to head() to get just the first few rows
# 2.2 hint->####################################################################################################################### use geom_point()
# 2.3 hint->####################################################################################################################### use facet_wrap()
# 3.1 hint->####################################################################################################################### langs / population
# 3.2 hint->####################################################################################################################### + labs(title="title", x="x label", y="y label")
# 4.1 hint->####################################################################################################################### growing.season > median(growing.season)
# 4.2 hint->####################################################################################################################### season.length = if_else(LOGICAL_EXPRESSION, "long", "short")
# 4.4 hint->####################################################################################################################### you'll need group_by() and summarise()
# 4.4 hint->####################################################################################################################### the formula for the upper bound of the CI is: mean(x) + 1.96 * (sd(x)/sqrt(length(x)))

